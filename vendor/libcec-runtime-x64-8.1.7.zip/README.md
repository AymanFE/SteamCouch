![Pulse-Eight logo](https://pulseeight.files.wordpress.com/2016/02/pulse-eight-logo-white-on-green.png?w=200)

# About
This library provides support for Pulse-Eight's USB-CEC adapter and other CEC capable hardware, like the Raspberry Pi.

A list of FAQ (Frequently Asked Questions) can be found on [libCEC's FAQ page](http://libcec.pulse-eight.com/faq).

.Net client applications, previously part of this repository, have been moved to [this repository](https://github.com/Pulse-Eight/cec-dotnet).

# API documentation

Full API reference — with install and usage guides — for every binding is
published at **[pulse-eight.github.io/libcec](https://pulse-eight.github.io/libcec/)**:

* [C / C++](https://pulse-eight.github.io/libcec/cpp/) — the native `ICECAdapter` interface and the C API
* [.NET](https://pulse-eight.github.io/libcec/dotnet/) — the managed `LibCecSharp` binding
* [Node.js](https://pulse-eight.github.io/libcec/nodejs/) — the N-API addon
* [Python](https://pulse-eight.github.io/libcec/python/) — the SWIG `cec` module
* [Rust](https://pulse-eight.github.io/libcec/rust/) — the `libcec` crate

The docs are generated from this source tree; see [docs/api/README.md](docs/api/README.md).

# Packages

Three bindings are published to their language's registry, from 8.1.6 onwards.
Each binds the native library rather than containing it, so libCEC itself still
has to be installed — see the platform sections below.

| | install | |
|---|---|---|
| .NET | `dotnet add package LibCecSharp` | [nuget.org](https://www.nuget.org/packages/LibCecSharp) |
| Node.js | `npm install libcec` | [npmjs.com](https://www.npmjs.com/package/libcec) |
| Rust | `cargo add libcec` | [crates.io](https://crates.io/crates/libcec) |

C, C++ and Python come from the platform packages: `libcec8-dev` and
`python-libcec` on Debian/Ubuntu, or the Windows installer.

# Supported platforms

## Linux & BSD
See [docs/README.linux.md](docs/README.linux.md).

## Apple OS X
See [docs/README.osx.md](docs/README.osx.md).

## Microsoft Windows
See [docs/README.windows.md](docs/README.windows.md).

# Supported hardware
* [Pulse-Eight USB-CEC Adapter](https://www.pulse-eight.com/p/104/usb-hdmi-cec-adapter)
* [Pulse-Eight Intel NUC CEC Adapter](https://www.pulse-eight.com/p/154/intel-nuc-hdmi-cec-adapter)
* [Pulse-Eight CEC Adapter for Skull Canyon and Hades Canyon NUC systems](https://www.pulse-eight.com/p/207/skull-canyon-nuc-cec-adapter)
* [Raspberry Pi](https://www.raspberrypi.org/)
* Some Exynos SoCs
* NXP TDA995x
* Odroid C2 (Amlogic S905)

# Developers
See [docs/README.developers.md](docs/README.developers.md).

# Vendor specific notes

## Panasonic
* On Panasonic to enable media control buttons on bottom of the remote, you may have to change the operation mode. To change it, press bottom Power-button, keep it pressed, and press 7 3 Stop. After releasing Power-button, Play, Pause, etc should work in XBMC.

## Raspberry Pi
* If your TV cannot detect the Raspberry Pi's CEC, or if the the Pi can't detect the TV, try adding the following line in `/boot/config.txt` and reboot the Pi: `hdmi_force_hotplug=1`
